<?php

include_once 'Config.php';

class Application {

    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function getAllApplication() {
        $query = "SELECT * FROM application";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAllRessources() {
        $query = "SELECT * FROM ressources";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getAllConsommateurs() {
        $query = "SELECT * FROM consommateurs";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    public function getConsommateurById($id) {
        $query = "SELECT * FROM consommateurs JOIN application ON conso.id = app.id WHERE conso.id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getTop5(){
        $query = "SELECT application.nom, SUM(consommation.volume) AS volume_total FROM application JOIN consommation ON application.app_id = consommation.app_id GROUP BY application.app_id, application.nom ORDER BY volume_total DESC LIMIT 5;";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } 

    public function ComparaisonRessources() {
        $query = "SELECT c.mois, SUM(CASE WHEN r.nom = 'Stockage' THEN c.volume ELSE 0 END) AS 'Stockage (Go)', SUM(CASE WHEN r.nom = 'Réseau' THEN c.volume ELSE 0 END) AS 'Réseau (Go)' FROM consommation c JOIN ressource r ON r.res_id = c.res_id GROUP BY c.mois ORDER BY c.mois ASC;";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function Evolution() {
        $query = "SELECT mois,SUM(volume) as 'Total (unité cumulées)' FROM consommation GROUP BY mois ORDER BY mois ASC;";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
}