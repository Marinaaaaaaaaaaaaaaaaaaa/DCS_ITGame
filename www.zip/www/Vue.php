<?php

include_once 'config.php';
include_once 'Modele.php';

$app = new Application($pdo);
$top5 = $app->getTop5();
$comparaison = $app->ComparaisonRessources();
$evolution = $app->Evolution();

?>

<!DOCTYPE html>
<html lang="fr">

<body>

<div class="container">

    <div class="Sidebar">
        <button class="tab-button active" onclick="showTab(1)">Top application</button>
        <button class="tab-button" onclick="showTab(2)">Évolution mensuelle</button>
        <button class="tab-button" onclick="showTab(3)">Comparaison des ressources</button>
    </div>

    <div id="tab1" class="tab-content active">
        <h2>Top 5 des applications en fonction de la consommation total</h2>
            <table border="1">
                <tr>
                    <th>Application</th>
                    <th>Volume Total</th>
                </tr>

                <?php foreach ($top5 as $row): ?>
                    <tr>
                        <td><?= ($row['nom']) ?></td>
                        <td><?= ($row['volume_total']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
    </div>

    <div id="tab2" class="tab-content">
        <h2>Évolution mensuelle des campus</h2>

            <table border="1">
                <tr>
                    <th>Mois</th>
                    <th>Total (unité cumulées)</th>
                </tr>

                <?php foreach ($evolution as $row): ?>
                    <tr>
                        <td><?= ($row['mois']) ?></td>
                        <td><?= ($row['Total (unité cumulées)']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>

    </div>

    <div id="tab3" class="tab-content">
        <h2>Comparaison des ressources Stockage et Réseau</h2>

        <table border="1">
                <tr>
                    <th>Mois</th>
                    <th>Stockage (Go)</th>
                    <th>Réseau (Go)</th>
                </tr>

                <?php foreach ($comparaison as $row): ?>
                    <tr>
                        <td><?= ($row['mois']) ?></td>
                        <td><?= ($row['Stockage (Go)']) ?></td>
                        <td><?= ($row['Réseau (Go)']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>

    </div>

</div>

<script>
    function showTab(tabNumber) {
        // Masquer tous les contenus
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.classList.remove('active');
        });

        // Désactiver tous les boutons
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.remove('active');
        });

        // Activer le contenu sélectionné
        document.getElementById('tab' + tabNumber).classList.add('active');

        // Activer le bouton correspondant
        document.querySelectorAll('.tab-button')[tabNumber - 1].classList.add('active');
    }
</script>

</body>

<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            Display: flex;
            justify-content: center;
            background-color: #ffffff;
            padding: 20px;
        }

        .container {
            width: 80%;
            height: 80vh;
            display: flex;
            background-color: #f0f0f0;
            padding: 20px;
            border-radius: 8px;
        }

        .Sidebar {
            width: 200px;
            display: flex;
            flex-direction: column;
            gap: 15px; 
            margin-right: 60px;
        }

        .tab-button {
            Display: flex;
            background-color: #e0e0e0;
            border: 1px solid #999;
            padding: 8px 15px;
            cursor: pointer;
            margin-right: 5px;
        }

        .tab-button.active {
            background-color: #c0c0c0;
            font-weight: bold;
        }

        .tab-content {
            display: none;
            flex-direction: column;
            justify-content: center;
        }

        .tab-content.active {
            display: block;
        }

        h2 {
            margin-top: 20px;
        }
    </style>
</head>

</html>